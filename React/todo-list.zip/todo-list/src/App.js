import './App.css';
import React from "react";
import List from './Components/List';


function App() {
  return (
    <div>
      <List />
    </div>
  )
}

export default App;
