import React, { useEffect } from 'react';
import axios from 'axios';
import {Link} from 'react-router-dom';

// const {product, setProduct}= props
// const {price, setPrice} =props
// const {description, setDescription} =props

const All = (props) => {

    const {list,setList} = props;
    
    useEffect(() =>{
        axios.get("http://localhost:8000/api/products")
    
            .then((res) => {
                console.log("this is line 16", res);
                console.log("this is line 17", res.data);
                setList(res.data.allProducts)
            })
            .catch((err) => console.log(err)
            )

    }, [setList])
   
    return (
        <div>
            <div className='break'> </div>
            <div>
                <p>All Products:</p>
            </div>
            {
                list.map((product, index) =>(
                    <div key={product._id}>
                        <Link to={`/product/${product._id}`}>{product.product}</Link>
                        <p></p>
                        <p></p>
                    </div>
                ))
            }
        </div>
    );
}

export default All;
