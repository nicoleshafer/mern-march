import './App.css';
import One from './components/One';
import {BrowserRouter, Routes, Route} from "react-router-dom"
import Main from './views/Main';

function App() {

  return (
    <div className="App">

      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Main />}/>
          <Route path="/product/:_id" element={<One />}/>
        </Routes>
      </BrowserRouter>
      
    </div>

    
  );
}

export default App;
