//Problem 1
//Yes you are giving the const random cars to the entire array

//Problem 2
//Yes I think this will work

//Problem 3
//Yes this will create a new const linked to the persons array password

//Problem 4
//i think it will produce an error becuase the numbers are == strictly equal

//Problem 5
//I dont think this will work because the willthiswork const is trying to be taken from an array that does not exist - it only exists inside an array